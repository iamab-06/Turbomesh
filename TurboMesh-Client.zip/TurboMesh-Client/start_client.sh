#!/usr/bin/env bash
echo "==================================================="
echo "            TurboMesh Client Node"
echo "==================================================="

if [ ! -d "venv" ]; then
    echo "Creating Python virtual environment..."
    python3 -m venv venv
    source venv/bin/activate
    echo "Installing dependencies..."
    pip install -r requirements.txt
else
    source venv/bin/activate
fi

echo "Starting TurboMesh Client on http://localhost:8001..."
python3 main.py --host 0.0.0.0 --port 8001
