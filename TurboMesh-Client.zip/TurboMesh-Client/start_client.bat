@echo off
title TurboMesh Client
echo ===================================================
echo             TurboMesh Client Node
echo ===================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in your PATH!
    echo Please install Python 3.9+ from https://www.python.org/
    pause
    exit /b 1
)

if not exist "venv" (
    echo Creating Python virtual environment...
    python -m venv venv
    call venv\Scripts\activate.bat
    echo Installing dependencies...
    pip install -r requirements.txt
) else (
    call venv\Scripts\activate.bat
)

echo.
echo Starting TurboMesh Client Dashboard on http://localhost:8001...
start http://localhost:8001
python main.py --host 0.0.0.0 --port 8001
pause
