# TurboMesh Client ⚡

Standalone client application for **TurboMesh** distributed computer vision and generative AI.

Install and run this client on any secondary machine (laptop, desktop, or mobile device on the network) to control and offload heavy AI computation to your TurboMesh Host GPU computer.

---

## 🌟 Supported Workloads (Remote GPU Offload)

1. **🎨 AI Image Generation (Prompt-to-Image)**:
   - Send descriptive text prompts to the Host GPU.
   - Select between **Stable Diffusion Turbo (Real-Time Photorealistic)**, **SD v1.5**, **SSD-1B**, or instant neural synthesis.
   - Customize resolution (512×512, 768×512, 512×768), artistic styles, and seed variations.
   - Interactive zoom preview, single-click image download, and variation generator.

2. **🎯 Object Detection & Traffic Analytics**:
   - Upload images to run remote YOLOv8 object detection.
   - Real-time vehicle counting, bounding box overlays, and license plate detection.

3. **🔍 Deep Forensic Image Similarity**:
   - Submit reference and target images.
   - Cosine ResNet feature embeddings, SSIM difference heatmaps, and ORB feature correspondences.

4. **✋ Hand Sign Landmark Training & Live Webcam Inference**:
   - Upload dataset archives for remote MediaPipe 21-point 3D landmark extraction and classifier training.
   - Stream live camera frames locally through the trained gesture model.

---

## 🚀 Setup on a New Machine

### Prerequisites
- Python 3.9, 3.10, 3.11, or 3.12
- Any modern web browser (Google Chrome, Microsoft Edge, Firefox, Safari)

---

### One-Click Launch

#### Windows:
Double-click **`start_client.bat`**. 
- It will automatically set up an isolated virtual environment (`venv`).
- Installs the required packages from `requirements.txt`.
- Launches the web dashboard and opens `http://localhost:8001` in your default browser.

#### Linux / macOS:
```bash
chmod +x start_client.sh
./start_client.sh
```

---

### Manual Launch (Terminal)

```bash
# 1. Create virtual environment
python -m venv venv

# 2. Activate virtual environment
# Windows:
.\venv\Scripts\activate
# macOS / Linux:
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Start the client
python main.py --port 8001
```

---

## 🔗 Connecting to the TurboMesh Host

1. Ensure both your client machine and the Host machine are on the same local network (Wi-Fi or LAN).
2. On the **Host machine**, start the host (`cd host && python main.py --host 0.0.0.0 --port 8000`).
3. Note the **Host LAN IP** (e.g. `192.168.1.50`), **Port** (`8000`), and the **6-digit Pairing Code** displayed on the Host dashboard.
4. On your **Client machine**, open `http://localhost:8001`.
5. Enter the Host IP, Port, and Pairing Code, then click **Connect**.
6. On the Host screen, click **Allow** on the incoming pairing notification.
7. Your client dashboard will immediately connect and unlock all remote GPU workloads!
